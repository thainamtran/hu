#Matthew Korn

plot(diamond$CARAT,diamond$PRICE)

#calculate correlation
cor(diamond$CARAT,diamond$PRICE)

#regression data
regDiamonds = lm(diamond$PRICE~diamond$CARAT)
regDiamonds

#import FCAT dataset
plot(fcat$POVERTY,fcat$MATH)
cor(fcat$POVERTY,fcat$MATH)
regFcat = lm(fcat$MATH~fcat$POVERTY)
regFcat
b0=189.8158
b1=-0.3054
x=20
b0+(b1*x)

#summary of diamonds
summary(diamond$CARAT)

#summary of regFcat
summary(regFcat)

qt=qt(.975,df=20)
qt
stderror =.04759
#confidence interal
b1+(qt*stderror)
b1-(qt*stderror)

tstat=b1/stderror
tstat

confint(regFcat,'fcat$POVERTY',level=0.95)

# new example part 6
x=diamond$CARAT
y=diamond$PRICE
new=data.frame(x=.6)
conf = predict(lm(y~x),new,interval="confidence")
round(conf,digits=0)

pred = predict(lm(y~x),new,interval="prediction")
round(pred,digits=0)

preds=predict(regDiamonds,interval="prediction")
confid=predict(regDiamonds,interval="confidence")

plot(x,y)
lines(x,preds[,1],col="blue",lwd=2)
lines(x,preds[,2],col="green",lwd=2)
lines(x,preds[,3],col="green",lwd=2)
lines(x,confid[,2],col="red",lwd=2)
lines(x,confid[,3],col="red",lwd=2)